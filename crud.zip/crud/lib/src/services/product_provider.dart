import 'dart:convert';

import 'package:http/http.dart' as http;

import 'package:formvalidation/src/model/product_model.dart';

class ProductPrvider{

  final String _url = 'https://flutter-varios-3121f.firebaseio.com';


  //CREAR PRODUCTOS

  Future<bool> createProduct (ProductModel product) async{

    final url = '$_url/productos.json';

    final resp = await http.post(url, body: productoModelToJson(product));

    final decodedData = json.decode(resp.body);

    print(decodedData);

    return true;

  }

  //MODIFICAR PRODUCTO

  Future<bool> EditProduct (ProductModel product) async{

    final url = '$_url/productos/${product.id}.json';

    final resp = await http.put(url, body: productoModelToJson(product));

    final decodedData = json.decode(resp.body);

    print(decodedData);

    return true;

  }



  //MOSTRAR INFORMACION DE LA BASE DE DATOS

  Future<List<ProductModel>> LoadData() async{

    final url = '$_url/productos.json';

    final resp = await http.get(url);

    final Map<String, dynamic> decodedData = json.decode(resp.body);

    final List<ProductModel> product = new List();

    if (decodedData == null) return [];
    
    decodedData. forEach((id, prod){

      final prodTemp = ProductModel.fromJson(prod);
      prodTemp.id = id;

      product.add(prodTemp);

    });

    return product;

  }

  //ELIMINAR LOS REGISTROS
Future<int> DeleteProduct(String id) async{

  final url = '$_url/productos/$id.json';

  final resp = await http.delete(url);

  print (json.decode(resp.body));

return 1;
}

}